import {useState} from 'react';
import TodoPage from './TodoPage';
import SingleTodoPage from './SingleTodoPage'
function App() {
    return (
        <SingleTodoPage/>
    )
}

export default App
