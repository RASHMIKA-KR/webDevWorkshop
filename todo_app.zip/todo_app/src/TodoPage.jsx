import axios from 'axios';
import { useState } from 'react';
function TodoPage() {
    const [todo, setTodo] = useState([]);
    const fetchData = async () => {
        const res = await axios
            .get('https://jsonplaceholder.typicode.com/todos');
        setTodo(res.data);
    }
    fetchData()
    return (
        <>
            <div>TodoPage</div>
            <ul>
                {
                    todo.map((ele, index) => {
                        return <li>{ele.title}</li>
                    })
                }
            </ul>
        </>
    )
}
export default TodoPage
