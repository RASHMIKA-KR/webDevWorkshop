import {useState} from 'react'
import axios from 'axios'
function SingleTodoPage() {
    const [todo, setTodo] = useState({
        id: "",
        title: "",
        completed: ""
    });
    const fetchData = async () => {
        const res = await axios
            .get('https://jsonplaceholder.typicode.com/todos/1');
        setTodo(res.data);
    }
    fetchData()
    return (
        <div>
            Id: {todo.id}<br/>
            Name: {todo.title}<br/>
            Completed: {String(todo.completed)}
        </div>
    )
}

export default SingleTodoPage
